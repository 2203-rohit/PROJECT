#include <math.h>

//Storing the coefficients
double coefficients[2];

// Calcuating Coefficents Declaration
double* calculate_coefficients(double[],double[],int);

// Linear Regression Prediction
double linearRegression(double a,double b,double x){
    //X: input , a,b: coefficents
    return  (a+(b*x));
}

// Calcuating Coefficents Definition
double* calculate_coefficients(double X[], double y[],int n){
    //X: area sq.ft , y:price
    // Sum Variables
    double sumX=0,sumy=0,sumXy=0,sumX2=0;
    //coefficients
    double a,b;
	int i;
    for(i=0;i<n;i++)
    {
        sumX += X[i];
        sumX2 += pow(X[i],2);
        sumy+= y[i];
        sumXy+= X[i]*y[i];
    }

    a=((sumX2*sumy -sumX*sumXy)*1.0/(n*sumX2-pow(sumX,2))*1.0);
    b=((n*sumXy-sumX*sumy)*1.0/(n*sumX2-pow(sumX,2))*1.0);

    coefficients[0]=a;
    coefficients[1]=b;

    return coefficients;
}
