#include "data.h"
#include "linear_regression.h"
#include <stdio.h>
#include <stdlib.h>

void displayData();
void displayData(){
    system("cls");
        printf("area , price");
	int i;
    for( i=0;i<sizeof(price)/sizeof(price[0]);i++){
        printf("\n%.2f , %.2f",area_sqft[i],price[i]);
    }
}
void header();
void header(){
	printf("\n");
    printf("\t\t\t\t********************************************\n ");
	printf("\t\t\t\t******* HOUSING PRICE PREDICTION ***********\n");
	printf("\t\t\t\t********************************************");
}
//main driver
int main() {
    system("cls");
    double *coeff; double area=0.0;

    coeff = calculate_coefficients(area_sqft,price,DATASET_SIZE);

    double a = coeff[0];
    double b = coeff[1];

    //displayData(); //Uncomment and Call it to display data
    header();
    
    while(1){
    	
    	printf("\n\n\n\t\t\t\tEnter the Area of flat (sq. ft): ");
    	scanf("%lf",&area);
    	
    	double price = linearRegression(a,b,area);
    	printf("\n\n\t\t\t\t Area of land: %g sq. ft, \n\n\t\t\t\t Expected Price: Rs. %.2f",area,price,"\n");
    	
	}

    return 0;
}
