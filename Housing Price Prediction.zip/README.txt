1. price.csv contains the area:price data in csv format
2. data.h contains the same information stored in an 1D array
3. linear_regression.h implements the linear regression algorithm using C language.
4. There's also an executable program to run without any compilation.

* The Program takes the input until the user explicitly closes the application.
___________________________________________________________________________________